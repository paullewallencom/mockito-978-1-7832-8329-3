package com.packtpub.chapter09;

public class Person {

}
