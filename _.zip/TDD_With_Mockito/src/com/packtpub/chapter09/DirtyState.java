package com.packtpub.chapter09;

public enum DirtyState {
 fresh(), dirty(), insert();
}
