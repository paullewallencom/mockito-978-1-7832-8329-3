package com.packtpub.chapter09;

public enum Sex {
  Male(), Female(), DontKnow();
}
