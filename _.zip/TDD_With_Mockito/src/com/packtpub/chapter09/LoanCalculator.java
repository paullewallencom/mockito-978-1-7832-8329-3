package com.packtpub.chapter09;

public class LoanCalculator {

	public void calculate(Person person) {
		// TODO Auto-generated method stub
		
	}

}
