package com.packtpub.chapter09;

public enum ArchitectureConstants {
  DBUrl(), DBUserName(), DBPassword();
}
