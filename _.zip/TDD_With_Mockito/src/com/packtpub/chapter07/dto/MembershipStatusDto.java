package com.packtpub.chapter07.dto;

public class MembershipStatusDto {

	private double deductable;

	public double getDeductable() {
		return deductable;
	}

	public void setDeductable(double deductable) {
		this.deductable = deductable;
	}
}
