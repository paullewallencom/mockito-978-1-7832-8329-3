package com.packtpub.chapter02;

public enum ConnectionType {
 TWO_G(), THREE_G(), FOUR_G();
}
