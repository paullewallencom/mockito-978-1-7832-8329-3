package com.packtpub.chapter08;

import java.util.List;

public interface SortingAlgorithm<T> {
   public void sort(List<T> object);
}
