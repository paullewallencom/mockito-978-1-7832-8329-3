package com.packtpub.chapter08;

import java.util.List;


public class HeapSortAlgorithm<T> implements SortingAlgorithm<T> {

	@Override
	public void sort(List<T> object) {
		// TODO Auto-generated method stub
		
	}

}
