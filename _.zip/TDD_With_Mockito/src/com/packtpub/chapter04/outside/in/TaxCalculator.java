package com.packtpub.chapter04.outside.in;

public interface TaxCalculator {

	double calculate(double taxableIncome);
}
