package com.packtpub.appendix.junit4;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({JUnit4Test.class, My2ndTest.class})
public class JunitSuit {

}
